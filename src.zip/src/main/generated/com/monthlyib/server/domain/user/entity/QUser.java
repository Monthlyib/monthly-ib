package com.monthlyib.server.domain.user.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QUser is a Querydsl query type for User
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QUser extends EntityPathBase<User> {

    private static final long serialVersionUID = -2031569273L;

    public static final QUser user = new QUser("user");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    public final StringPath address = createString("address");

    public final EnumPath<com.monthlyib.server.constant.Authority> authority = createEnum("authority", com.monthlyib.server.constant.Authority.class);

    public final StringPath birth = createString("birth");

    public final StringPath country = createString("country");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    public final StringPath email = createString("email");

    public final DatePath<java.time.LocalDate> expirationDate = createDate("expirationDate", java.time.LocalDate.class);

    public final StringPath grade = createString("grade");

    public final EnumPath<com.monthlyib.server.constant.LoginType> loginType = createEnum("loginType", com.monthlyib.server.constant.LoginType.class);

    public final BooleanPath marketingTermsCheck = createBoolean("marketingTermsCheck");

    public final StringPath memo = createString("memo");

    public final StringPath nickName = createString("nickName");

    public final StringPath password = createString("password");

    public final BooleanPath privacyTermsCheck = createBoolean("privacyTermsCheck");

    public final NumberPath<Integer> remainQuestionCount = createNumber("remainQuestionCount", Integer.class);

    public final NumberPath<Integer> remainTutoringCount = createNumber("remainTutoringCount", Integer.class);

    public final ListPath<String, StringPath> roles = this.<String, StringPath>createList("roles", String.class, StringPath.class, PathInits.DIRECT2);

    public final StringPath school = createString("school");

    public final DatePath<java.time.LocalDate> subscriptionDate = createDate("subscriptionDate", java.time.LocalDate.class);

    public final NumberPath<Integer> subscriptionDay = createNumber("subscriptionDay", Integer.class);

    public final NumberPath<Long> subscriptionId = createNumber("subscriptionId", Long.class);

    public final NumberPath<java.math.BigDecimal> subscriptionPrice = createNumber("subscriptionPrice", java.math.BigDecimal.class);

    public final BooleanPath termsOfUseCheck = createBoolean("termsOfUseCheck");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public final NumberPath<Long> userId = createNumber("userId", Long.class);

    public final StringPath username = createString("username");

    public final EnumPath<com.monthlyib.server.constant.UserStatus> userStatus = createEnum("userStatus", com.monthlyib.server.constant.UserStatus.class);

    public final ListPath<Long, NumberPath<Long>> videoLessonsIdList = this.<Long, NumberPath<Long>>createList("videoLessonsIdList", Long.class, NumberPath.class, PathInits.DIRECT2);

    public QUser(String variable) {
        super(User.class, forVariable(variable));
    }

    public QUser(Path<? extends User> path) {
        super(path.getType(), path.getMetadata());
    }

    public QUser(PathMetadata metadata) {
        super(User.class, metadata);
    }

}

