package com.monthlyib.server.domain.storage.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QStorageFolder is a Querydsl query type for StorageFolder
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QStorageFolder extends EntityPathBase<StorageFolder> {

    private static final long serialVersionUID = -595259259L;

    public static final QStorageFolder storageFolder = new QStorageFolder("storageFolder");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    public final StringPath fullPath = createString("fullPath");

    public final StringPath name = createString("name");

    public final NumberPath<Long> parentsFolderId = createNumber("parentsFolderId", Long.class);

    public final StringPath parentsFolderName = createString("parentsFolderName");

    public final EnumPath<com.monthlyib.server.constant.StorageFolderStatus> status = createEnum("status", com.monthlyib.server.constant.StorageFolderStatus.class);

    public final NumberPath<Long> storageFolderId = createNumber("storageFolderId", Long.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public QStorageFolder(String variable) {
        super(StorageFolder.class, forVariable(variable));
    }

    public QStorageFolder(Path<? extends StorageFolder> path) {
        super(path.getType(), path.getMetadata());
    }

    public QStorageFolder(PathMetadata metadata) {
        super(StorageFolder.class, metadata);
    }

}

