package com.monthlyib.server.domain.storage.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QStorageFile is a Querydsl query type for StorageFile
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QStorageFile extends EntityPathBase<StorageFile> {

    private static final long serialVersionUID = -1792801965L;

    public static final QStorageFile storageFile = new QStorageFile("storageFile");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    public final StringPath fileName = createString("fileName");

    public final StringPath fileUrl = createString("fileUrl");

    public final StringPath fullPath = createString("fullPath");

    public final NumberPath<Long> parentsFolderId = createNumber("parentsFolderId", Long.class);

    public final StringPath parentsFolderName = createString("parentsFolderName");

    public final NumberPath<Long> storageFileId = createNumber("storageFileId", Long.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public QStorageFile(String variable) {
        super(StorageFile.class, forVariable(variable));
    }

    public QStorageFile(Path<? extends StorageFile> path) {
        super(path.getType(), path.getMetadata());
    }

    public QStorageFile(PathMetadata metadata) {
        super(StorageFile.class, metadata);
    }

}

