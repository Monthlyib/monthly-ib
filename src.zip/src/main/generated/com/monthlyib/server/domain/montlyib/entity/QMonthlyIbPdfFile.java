package com.monthlyib.server.domain.montlyib.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QMonthlyIbPdfFile is a Querydsl query type for MonthlyIbPdfFile
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QMonthlyIbPdfFile extends EntityPathBase<MonthlyIbPdfFile> {

    private static final long serialVersionUID = -324222745L;

    public static final QMonthlyIbPdfFile monthlyIbPdfFile = new QMonthlyIbPdfFile("monthlyIbPdfFile");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    public final StringPath fileName = createString("fileName");

    public final NumberPath<Long> monthlyIbId = createNumber("monthlyIbId", Long.class);

    public final NumberPath<Long> monthlyIbPdfFileId = createNumber("monthlyIbPdfFileId", Long.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public final StringPath url = createString("url");

    public QMonthlyIbPdfFile(String variable) {
        super(MonthlyIbPdfFile.class, forVariable(variable));
    }

    public QMonthlyIbPdfFile(Path<? extends MonthlyIbPdfFile> path) {
        super(path.getType(), path.getMetadata());
    }

    public QMonthlyIbPdfFile(PathMetadata metadata) {
        super(MonthlyIbPdfFile.class, metadata);
    }

}

