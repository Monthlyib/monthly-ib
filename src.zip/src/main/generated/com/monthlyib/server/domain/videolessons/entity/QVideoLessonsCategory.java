package com.monthlyib.server.domain.videolessons.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QVideoLessonsCategory is a Querydsl query type for VideoLessonsCategory
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QVideoLessonsCategory extends EntityPathBase<VideoLessonsCategory> {

    private static final long serialVersionUID = 1736471855L;

    public static final QVideoLessonsCategory videoLessonsCategory = new QVideoLessonsCategory("videoLessonsCategory");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    public final StringPath categoryName = createString("categoryName");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    public final NumberPath<Long> parentsCategoryId = createNumber("parentsCategoryId", Long.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public final NumberPath<Long> videoCategoryId = createNumber("videoCategoryId", Long.class);

    public final EnumPath<com.monthlyib.server.constant.VideoCategoryStatus> videoCategoryStatus = createEnum("videoCategoryStatus", com.monthlyib.server.constant.VideoCategoryStatus.class);

    public QVideoLessonsCategory(String variable) {
        super(VideoLessonsCategory.class, forVariable(variable));
    }

    public QVideoLessonsCategory(Path<? extends VideoLessonsCategory> path) {
        super(path.getType(), path.getMetadata());
    }

    public QVideoLessonsCategory(PathMetadata metadata) {
        super(VideoLessonsCategory.class, metadata);
    }

}

