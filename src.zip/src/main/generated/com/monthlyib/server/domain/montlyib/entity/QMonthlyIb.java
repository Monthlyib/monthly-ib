package com.monthlyib.server.domain.montlyib.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QMonthlyIb is a Querydsl query type for MonthlyIb
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QMonthlyIb extends EntityPathBase<MonthlyIb> {

    private static final long serialVersionUID = 1466805927L;

    public static final QMonthlyIb monthlyIb = new QMonthlyIb("monthlyIb");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    public final StringPath content = createString("content");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    public final NumberPath<Long> monthlyIbId = createNumber("monthlyIbId", Long.class);

    public final NumberPath<Long> monthlyIbThumbnailFileId = createNumber("monthlyIbThumbnailFileId", Long.class);

    public final StringPath monthlyIbThumbnailFileName = createString("monthlyIbThumbnailFileName");

    public final StringPath monthlyIbThumbnailFileUrl = createString("monthlyIbThumbnailFileUrl");

    public final StringPath title = createString("title");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public QMonthlyIb(String variable) {
        super(MonthlyIb.class, forVariable(variable));
    }

    public QMonthlyIb(Path<? extends MonthlyIb> path) {
        super(path.getType(), path.getMetadata());
    }

    public QMonthlyIb(PathMetadata metadata) {
        super(MonthlyIb.class, metadata);
    }

}

