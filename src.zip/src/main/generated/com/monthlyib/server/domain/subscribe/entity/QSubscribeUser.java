package com.monthlyib.server.domain.subscribe.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QSubscribeUser is a Querydsl query type for SubscribeUser
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QSubscribeUser extends EntityPathBase<SubscribeUser> {

    private static final long serialVersionUID = -1694208638L;

    public static final QSubscribeUser subscribeUser = new QSubscribeUser("subscribeUser");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    public final StringPath content = createString("content");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    public final DatePath<java.time.LocalDate> expirationDate = createDate("expirationDate", java.time.LocalDate.class);

    public final BooleanPath premium = createBoolean("premium");

    public final NumberPath<java.math.BigDecimal> price = createNumber("price", java.math.BigDecimal.class);

    public final NumberPath<Integer> questionCount = createNumber("questionCount", Integer.class);

    public final NumberPath<Long> subscribeId = createNumber("subscribeId", Long.class);

    public final NumberPath<Integer> subscribeMonthPeriod = createNumber("subscribeMonthPeriod", Integer.class);

    public final EnumPath<com.monthlyib.server.constant.SubscribeStatus> subscribeStatus = createEnum("subscribeStatus", com.monthlyib.server.constant.SubscribeStatus.class);

    public final NumberPath<Long> subscribeUserId = createNumber("subscribeUserId", Long.class);

    public final DatePath<java.time.LocalDate> subscriptionDate = createDate("subscriptionDate", java.time.LocalDate.class);

    public final NumberPath<Integer> subscriptionDay = createNumber("subscriptionDay", Integer.class);

    public final StringPath title = createString("title");

    public final NumberPath<Integer> tutoringCount = createNumber("tutoringCount", Integer.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public final NumberPath<Long> userId = createNumber("userId", Long.class);

    public final StringPath userName = createString("userName");

    public final StringPath userNickName = createString("userNickName");

    public final NumberPath<Integer> videoLessonsCount = createNumber("videoLessonsCount", Integer.class);

    public final ListPath<Long, NumberPath<Long>> videoLessonsIdList = this.<Long, NumberPath<Long>>createList("videoLessonsIdList", Long.class, NumberPath.class, PathInits.DIRECT2);

    public QSubscribeUser(String variable) {
        super(SubscribeUser.class, forVariable(variable));
    }

    public QSubscribeUser(Path<? extends SubscribeUser> path) {
        super(path.getType(), path.getMetadata());
    }

    public QSubscribeUser(PathMetadata metadata) {
        super(SubscribeUser.class, metadata);
    }

}

