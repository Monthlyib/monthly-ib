package com.monthlyib.server.domain.subscribe.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QSubscribe is a Querydsl query type for Subscribe
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QSubscribe extends EntityPathBase<Subscribe> {

    private static final long serialVersionUID = -1120374505L;

    public static final QSubscribe subscribe = new QSubscribe("subscribe");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    public final StringPath color = createString("color");

    public final StringPath content = createString("content");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    public final StringPath fontColor = createString("fontColor");

    public final BooleanPath premium = createBoolean("premium");

    public final NumberPath<java.math.BigDecimal> price = createNumber("price", java.math.BigDecimal.class);

    public final NumberPath<Integer> questionCount = createNumber("questionCount", Integer.class);

    public final NumberPath<Long> subscribeId = createNumber("subscribeId", Long.class);

    public final NumberPath<Integer> subscribeMonthPeriod = createNumber("subscribeMonthPeriod", Integer.class);

    public final StringPath title = createString("title");

    public final NumberPath<Integer> tutoringCount = createNumber("tutoringCount", Integer.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public final NumberPath<Integer> videoLessonsCount = createNumber("videoLessonsCount", Integer.class);

    public final ListPath<Long, NumberPath<Long>> videoLessonsIdList = this.<Long, NumberPath<Long>>createList("videoLessonsIdList", Long.class, NumberPath.class, PathInits.DIRECT2);

    public QSubscribe(String variable) {
        super(Subscribe.class, forVariable(variable));
    }

    public QSubscribe(Path<? extends Subscribe> path) {
        super(path.getType(), path.getMetadata());
    }

    public QSubscribe(PathMetadata metadata) {
        super(Subscribe.class, metadata);
    }

}

