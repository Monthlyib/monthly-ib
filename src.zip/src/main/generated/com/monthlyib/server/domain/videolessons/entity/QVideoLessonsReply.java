package com.monthlyib.server.domain.videolessons.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QVideoLessonsReply is a Querydsl query type for VideoLessonsReply
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QVideoLessonsReply extends EntityPathBase<VideoLessonsReply> {

    private static final long serialVersionUID = -659967911L;

    public static final QVideoLessonsReply videoLessonsReply = new QVideoLessonsReply("videoLessonsReply");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    public final NumberPath<Long> authorId = createNumber("authorId", Long.class);

    public final StringPath authorNickname = createString("authorNickname");

    public final StringPath authorUsername = createString("authorUsername");

    public final StringPath content = createString("content");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    public final NumberPath<Double> star = createNumber("star", Double.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public final NumberPath<Long> videoLessonsId = createNumber("videoLessonsId", Long.class);

    public final NumberPath<Long> videoLessonsReplyId = createNumber("videoLessonsReplyId", Long.class);

    public final SetPath<com.monthlyib.server.domain.user.entity.User, com.monthlyib.server.domain.user.entity.QUser> voter = this.<com.monthlyib.server.domain.user.entity.User, com.monthlyib.server.domain.user.entity.QUser>createSet("voter", com.monthlyib.server.domain.user.entity.User.class, com.monthlyib.server.domain.user.entity.QUser.class, PathInits.DIRECT2);

    public QVideoLessonsReply(String variable) {
        super(VideoLessonsReply.class, forVariable(variable));
    }

    public QVideoLessonsReply(Path<? extends VideoLessonsReply> path) {
        super(path.getType(), path.getMetadata());
    }

    public QVideoLessonsReply(PathMetadata metadata) {
        super(VideoLessonsReply.class, metadata);
    }

}

