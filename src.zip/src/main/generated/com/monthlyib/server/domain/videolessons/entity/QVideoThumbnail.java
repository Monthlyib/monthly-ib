package com.monthlyib.server.domain.videolessons.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QVideoThumbnail is a Querydsl query type for VideoThumbnail
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QVideoThumbnail extends EntityPathBase<VideoThumbnail> {

    private static final long serialVersionUID = -619516350L;

    public static final QVideoThumbnail videoThumbnail = new QVideoThumbnail("videoThumbnail");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    public final StringPath fileName = createString("fileName");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public final StringPath url = createString("url");

    public final NumberPath<Long> videoLessonsId = createNumber("videoLessonsId", Long.class);

    public final NumberPath<Long> videoThumbnailId = createNumber("videoThumbnailId", Long.class);

    public QVideoThumbnail(String variable) {
        super(VideoThumbnail.class, forVariable(variable));
    }

    public QVideoThumbnail(Path<? extends VideoThumbnail> path) {
        super(path.getType(), path.getMetadata());
    }

    public QVideoThumbnail(PathMetadata metadata) {
        super(VideoThumbnail.class, metadata);
    }

}

