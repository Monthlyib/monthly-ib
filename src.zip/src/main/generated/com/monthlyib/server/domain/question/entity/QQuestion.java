package com.monthlyib.server.domain.question.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QQuestion is a Querydsl query type for Question
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QQuestion extends EntityPathBase<Question> {

    private static final long serialVersionUID = -136030019L;

    public static final QQuestion question = new QQuestion("question");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    public final NumberPath<Long> answerId = createNumber("answerId", Long.class);

    public final NumberPath<Long> authorId = createNumber("authorId", Long.class);

    public final StringPath authorNickName = createString("authorNickName");

    public final StringPath authorUsername = createString("authorUsername");

    public final StringPath content = createString("content");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    public final NumberPath<Long> questionId = createNumber("questionId", Long.class);

    public final EnumPath<com.monthlyib.server.constant.QuestionStatus> questionStatus = createEnum("questionStatus", com.monthlyib.server.constant.QuestionStatus.class);

    public final StringPath subject = createString("subject");

    public final StringPath title = createString("title");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public QQuestion(String variable) {
        super(Question.class, forVariable(variable));
    }

    public QQuestion(Path<? extends Question> path) {
        super(path.getType(), path.getMetadata());
    }

    public QQuestion(PathMetadata metadata) {
        super(Question.class, metadata);
    }

}

