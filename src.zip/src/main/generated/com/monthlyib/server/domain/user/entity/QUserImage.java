package com.monthlyib.server.domain.user.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QUserImage is a Querydsl query type for UserImage
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QUserImage extends EntityPathBase<UserImage> {

    private static final long serialVersionUID = 112131860L;

    public static final QUserImage userImage = new QUserImage("userImage");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    public final StringPath fileName = createString("fileName");

    public final StringPath fileUrl = createString("fileUrl");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public final NumberPath<Long> userId = createNumber("userId", Long.class);

    public final NumberPath<Long> userImageId = createNumber("userImageId", Long.class);

    public QUserImage(String variable) {
        super(UserImage.class, forVariable(variable));
    }

    public QUserImage(Path<? extends UserImage> path) {
        super(path.getType(), path.getMetadata());
    }

    public QUserImage(PathMetadata metadata) {
        super(UserImage.class, metadata);
    }

}

