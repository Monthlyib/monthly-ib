package com.monthlyib.server.domain.news.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QNewsFile is a Querydsl query type for NewsFile
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QNewsFile extends EntityPathBase<NewsFile> {

    private static final long serialVersionUID = -798953805L;

    public static final QNewsFile newsFile = new QNewsFile("newsFile");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    public final StringPath fileName = createString("fileName");

    public final NumberPath<Long> newsFileId = createNumber("newsFileId", Long.class);

    public final NumberPath<Long> newsId = createNumber("newsId", Long.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public final StringPath url = createString("url");

    public QNewsFile(String variable) {
        super(NewsFile.class, forVariable(variable));
    }

    public QNewsFile(Path<? extends NewsFile> path) {
        super(path.getType(), path.getMetadata());
    }

    public QNewsFile(PathMetadata metadata) {
        super(NewsFile.class, metadata);
    }

}

