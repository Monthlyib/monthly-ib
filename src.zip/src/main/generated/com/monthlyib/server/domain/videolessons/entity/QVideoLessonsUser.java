package com.monthlyib.server.domain.videolessons.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QVideoLessonsUser is a Querydsl query type for VideoLessonsUser
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QVideoLessonsUser extends EntityPathBase<VideoLessonsUser> {

    private static final long serialVersionUID = -713923460L;

    public static final QVideoLessonsUser videoLessonsUser = new QVideoLessonsUser("videoLessonsUser");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    public final EnumPath<com.monthlyib.server.constant.VideoLessonsUserStatus> status = createEnum("status", com.monthlyib.server.constant.VideoLessonsUserStatus.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public final NumberPath<Long> userId = createNumber("userId", Long.class);

    public final NumberPath<Long> videoLessonsId = createNumber("videoLessonsId", Long.class);

    public final NumberPath<Long> videoLessonsUserId = createNumber("videoLessonsUserId", Long.class);

    public QVideoLessonsUser(String variable) {
        super(VideoLessonsUser.class, forVariable(variable));
    }

    public QVideoLessonsUser(Path<? extends VideoLessonsUser> path) {
        super(path.getType(), path.getMetadata());
    }

    public QVideoLessonsUser(PathMetadata metadata) {
        super(VideoLessonsUser.class, metadata);
    }

}

