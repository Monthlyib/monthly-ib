package com.monthlyib.server.domain.videolessons.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QVideoLessons is a Querydsl query type for VideoLessons
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QVideoLessons extends EntityPathBase<VideoLessons> {

    private static final long serialVersionUID = -1512245999L;

    public static final QVideoLessons videoLessons = new QVideoLessons("videoLessons");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    public final StringPath chapterInfo = createString("chapterInfo");

    public final StringPath content = createString("content");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    public final StringPath duration = createString("duration");

    public final NumberPath<Long> firstCategoryId = createNumber("firstCategoryId", Long.class);

    public final StringPath firstCategoryName = createString("firstCategoryName");

    public final StringPath instructor = createString("instructor");

    public final NumberPath<Long> replyCount = createNumber("replyCount", Long.class);

    public final NumberPath<Long> secondCategoryId = createNumber("secondCategoryId", Long.class);

    public final StringPath secondCategoryName = createString("secondCategoryName");

    public final NumberPath<Double> starAverage = createNumber("starAverage", Double.class);

    public final NumberPath<Long> thirdCategoryId = createNumber("thirdCategoryId", Long.class);

    public final StringPath thirdCategoryName = createString("thirdCategoryName");

    public final StringPath title = createString("title");

    public final NumberPath<Double> totalStar = createNumber("totalStar", Double.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public final StringPath videoLessonsIbThumbnailUrl = createString("videoLessonsIbThumbnailUrl");

    public final NumberPath<Long> videoLessonsId = createNumber("videoLessonsId", Long.class);

    public final EnumPath<com.monthlyib.server.constant.VideoLessonsStatus> videoLessonsStatus = createEnum("videoLessonsStatus", com.monthlyib.server.constant.VideoLessonsStatus.class);

    public final NumberPath<Long> videoLessonsThumbnailId = createNumber("videoLessonsThumbnailId", Long.class);

    public QVideoLessons(String variable) {
        super(VideoLessons.class, forVariable(variable));
    }

    public QVideoLessons(Path<? extends VideoLessons> path) {
        super(path.getType(), path.getMetadata());
    }

    public QVideoLessons(PathMetadata metadata) {
        super(VideoLessons.class, metadata);
    }

}

