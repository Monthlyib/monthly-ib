package com.monthlyib.server.domain.videolessons.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QVideoLessonsSubChapter is a Querydsl query type for VideoLessonsSubChapter
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QVideoLessonsSubChapter extends EntityPathBase<VideoLessonsSubChapter> {

    private static final long serialVersionUID = 263011806L;

    public static final QVideoLessonsSubChapter videoLessonsSubChapter = new QVideoLessonsSubChapter("videoLessonsSubChapter");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    public final NumberPath<Integer> chapterIndex = createNumber("chapterIndex", Integer.class);

    public final EnumPath<com.monthlyib.server.constant.VideoChapterStatus> chapterStatus = createEnum("chapterStatus", com.monthlyib.server.constant.VideoChapterStatus.class);

    public final StringPath chapterTitle = createString("chapterTitle");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    public final NumberPath<Long> mainChapterId = createNumber("mainChapterId", Long.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public final StringPath videoFileUrl = createString("videoFileUrl");

    public final NumberPath<Long> videoLessonsId = createNumber("videoLessonsId", Long.class);

    public final NumberPath<Long> videoLessonsSubChapterId = createNumber("videoLessonsSubChapterId", Long.class);

    public QVideoLessonsSubChapter(String variable) {
        super(VideoLessonsSubChapter.class, forVariable(variable));
    }

    public QVideoLessonsSubChapter(Path<? extends VideoLessonsSubChapter> path) {
        super(path.getType(), path.getMetadata());
    }

    public QVideoLessonsSubChapter(PathMetadata metadata) {
        super(VideoLessonsSubChapter.class, metadata);
    }

}

