package com.monthlyib.server.domain.order.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QIbOrder is a Querydsl query type for IbOrder
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QIbOrder extends EntityPathBase<IbOrder> {

    private static final long serialVersionUID = -324850626L;

    public static final QIbOrder ibOrder = new QIbOrder("ibOrder");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    public final StringPath approvedAt = createString("approvedAt");

    public final NumberPath<Integer> balanceAmount = createNumber("balanceAmount", Integer.class);

    public final StringPath checkoutUrl = createString("checkoutUrl");

    public final StringPath country = createString("country");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    public final BooleanPath cultureExpense = createBoolean("cultureExpense");

    public final StringPath currency = createString("currency");

    public final NumberPath<Long> ibOrderId = createNumber("ibOrderId", Long.class);

    public final StringPath lastTransactionKey = createString("lastTransactionKey");

    public final StringPath method = createString("method");

    public final StringPath mId = createString("mId");

    public final StringPath orderId = createString("orderId");

    public final StringPath orderName = createString("orderName");

    public final StringPath paymentKey = createString("paymentKey");

    public final StringPath receiptUrl = createString("receiptUrl");

    public final StringPath requestedAt = createString("requestedAt");

    public final StringPath status = createString("status");

    public final NumberPath<Long> subscribeId = createNumber("subscribeId", Long.class);

    public final NumberPath<Integer> suppliedAmount = createNumber("suppliedAmount", Integer.class);

    public final NumberPath<Integer> taxFreeAmount = createNumber("taxFreeAmount", Integer.class);

    public final NumberPath<Integer> totalAmount = createNumber("totalAmount", Integer.class);

    public final StringPath type = createString("type");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public final BooleanPath useEscrow = createBoolean("useEscrow");

    public final NumberPath<Long> userId = createNumber("userId", Long.class);

    public final NumberPath<Integer> vat = createNumber("vat", Integer.class);

    public final StringPath version = createString("version");

    public QIbOrder(String variable) {
        super(IbOrder.class, forVariable(variable));
    }

    public QIbOrder(Path<? extends IbOrder> path) {
        super(path.getType(), path.getMetadata());
    }

    public QIbOrder(PathMetadata metadata) {
        super(IbOrder.class, metadata);
    }

}

