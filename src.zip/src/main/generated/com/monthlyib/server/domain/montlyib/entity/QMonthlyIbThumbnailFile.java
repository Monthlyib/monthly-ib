package com.monthlyib.server.domain.montlyib.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QMonthlyIbThumbnailFile is a Querydsl query type for MonthlyIbThumbnailFile
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QMonthlyIbThumbnailFile extends EntityPathBase<MonthlyIbThumbnailFile> {

    private static final long serialVersionUID = -1798296287L;

    public static final QMonthlyIbThumbnailFile monthlyIbThumbnailFile = new QMonthlyIbThumbnailFile("monthlyIbThumbnailFile");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    public final StringPath fileName = createString("fileName");

    public final NumberPath<Long> monthlyIbId = createNumber("monthlyIbId", Long.class);

    public final NumberPath<Long> monthlyIbThumbnailFileId = createNumber("monthlyIbThumbnailFileId", Long.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public final StringPath url = createString("url");

    public QMonthlyIbThumbnailFile(String variable) {
        super(MonthlyIbThumbnailFile.class, forVariable(variable));
    }

    public QMonthlyIbThumbnailFile(Path<? extends MonthlyIbThumbnailFile> path) {
        super(path.getType(), path.getMetadata());
    }

    public QMonthlyIbThumbnailFile(PathMetadata metadata) {
        super(MonthlyIbThumbnailFile.class, metadata);
    }

}

