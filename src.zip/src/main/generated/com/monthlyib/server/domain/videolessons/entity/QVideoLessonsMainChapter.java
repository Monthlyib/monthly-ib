package com.monthlyib.server.domain.videolessons.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QVideoLessonsMainChapter is a Querydsl query type for VideoLessonsMainChapter
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QVideoLessonsMainChapter extends EntityPathBase<VideoLessonsMainChapter> {

    private static final long serialVersionUID = 963209859L;

    public static final QVideoLessonsMainChapter videoLessonsMainChapter = new QVideoLessonsMainChapter("videoLessonsMainChapter");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    public final NumberPath<Integer> chapterIndex = createNumber("chapterIndex", Integer.class);

    public final EnumPath<com.monthlyib.server.constant.VideoChapterStatus> chapterStatus = createEnum("chapterStatus", com.monthlyib.server.constant.VideoChapterStatus.class);

    public final StringPath chapterTitle = createString("chapterTitle");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public final NumberPath<Long> videoLessonsId = createNumber("videoLessonsId", Long.class);

    public final NumberPath<Long> videoLessonsMainChapterId = createNumber("videoLessonsMainChapterId", Long.class);

    public QVideoLessonsMainChapter(String variable) {
        super(VideoLessonsMainChapter.class, forVariable(variable));
    }

    public QVideoLessonsMainChapter(Path<? extends VideoLessonsMainChapter> path) {
        super(path.getType(), path.getMetadata());
    }

    public QVideoLessonsMainChapter(PathMetadata metadata) {
        super(VideoLessonsMainChapter.class, metadata);
    }

}

