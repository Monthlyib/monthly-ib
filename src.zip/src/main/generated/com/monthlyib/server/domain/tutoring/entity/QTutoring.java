package com.monthlyib.server.domain.tutoring.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QTutoring is a Querydsl query type for Tutoring
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QTutoring extends EntityPathBase<Tutoring> {

    private static final long serialVersionUID = 602107593L;

    public static final QTutoring tutoring = new QTutoring("tutoring");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    public final DatePath<java.time.LocalDate> date = createDate("date", java.time.LocalDate.class);

    public final StringPath detail = createString("detail");

    public final NumberPath<Integer> hour = createNumber("hour", Integer.class);

    public final NumberPath<Integer> minute = createNumber("minute", Integer.class);

    public final NumberPath<Long> requestUserId = createNumber("requestUserId", Long.class);

    public final StringPath requestUsername = createString("requestUsername");

    public final StringPath requestUserNickName = createString("requestUserNickName");

    public final NumberPath<Long> tutoringId = createNumber("tutoringId", Long.class);

    public final EnumPath<com.monthlyib.server.constant.TutoringStatus> tutoringStatus = createEnum("tutoringStatus", com.monthlyib.server.constant.TutoringStatus.class);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public QTutoring(String variable) {
        super(Tutoring.class, forVariable(variable));
    }

    public QTutoring(Path<? extends Tutoring> path) {
        super(path.getType(), path.getMetadata());
    }

    public QTutoring(PathMetadata metadata) {
        super(Tutoring.class, metadata);
    }

}

