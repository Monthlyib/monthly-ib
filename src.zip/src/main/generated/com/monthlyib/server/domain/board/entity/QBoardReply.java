package com.monthlyib.server.domain.board.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QBoardReply is a Querydsl query type for BoardReply
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QBoardReply extends EntityPathBase<BoardReply> {

    private static final long serialVersionUID = -321129965L;

    public static final QBoardReply boardReply = new QBoardReply("boardReply");

    public final com.monthlyib.server.audit.QAuditable _super = new com.monthlyib.server.audit.QAuditable(this);

    public final NumberPath<Long> authorId = createNumber("authorId", Long.class);

    public final StringPath authorNickName = createString("authorNickName");

    public final StringPath authorUsername = createString("authorUsername");

    public final NumberPath<Long> boardId = createNumber("boardId", Long.class);

    public final NumberPath<Long> boardReplyId = createNumber("boardReplyId", Long.class);

    public final StringPath content = createString("content");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createAt = _super.createAt;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updateAt = _super.updateAt;

    public final SetPath<com.monthlyib.server.domain.user.entity.User, com.monthlyib.server.domain.user.entity.QUser> voter = this.<com.monthlyib.server.domain.user.entity.User, com.monthlyib.server.domain.user.entity.QUser>createSet("voter", com.monthlyib.server.domain.user.entity.User.class, com.monthlyib.server.domain.user.entity.QUser.class, PathInits.DIRECT2);

    public QBoardReply(String variable) {
        super(BoardReply.class, forVariable(variable));
    }

    public QBoardReply(Path<? extends BoardReply> path) {
        super(path.getType(), path.getMetadata());
    }

    public QBoardReply(PathMetadata metadata) {
        super(BoardReply.class, metadata);
    }

}

