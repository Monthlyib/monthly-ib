package com.monthlyib.server.domain.subscribe.service;


import com.monthlyib.server.api.subscribe.dto.SubscribePostDto;
import com.monthlyib.server.api.subscribe.dto.SubscribeResponseDto;
import com.monthlyib.server.api.subscribe.dto.SubscribeUserPatchDto;
import com.monthlyib.server.api.subscribe.dto.SubscribeUserResponseDto;
import com.monthlyib.server.constant.ErrorCode;
import com.monthlyib.server.constant.SubscribeStatus;
import com.monthlyib.server.domain.subscribe.entity.Subscribe;
import com.monthlyib.server.domain.subscribe.entity.SubscribeUser;
import com.monthlyib.server.domain.subscribe.repository.SubscribeRepository;
import com.monthlyib.server.domain.user.entity.User;
import com.monthlyib.server.domain.user.service.UserService;
import com.monthlyib.server.exception.ServiceLogicException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class SubscribeService {

    private final SubscribeRepository subscribeRepository;

    private final UserService userService;

    public List<SubscribeResponseDto> findAllSubscribe() {
        return subscribeRepository.findAllSubscribes()
                .stream().map(SubscribeResponseDto::of).toList();
    }

    public SubscribeUserResponseDto createSubscribeUser(Long subscribeId, User user, Long userId) {
        verifyActiveSubUserThrowError(userId);
        Subscribe subscribe = verifySubscribe(subscribeId);
        User findUser = userService.findUserEntity(userId);
        SubscribeUser newSubUser = SubscribeUser.create(subscribe, findUser, SubscribeStatus.ACTIVE);
        SubscribeUser saveSubUser = subscribeRepository.saveSubscribeUser(newSubUser);
        return SubscribeUserResponseDto.of(saveSubUser);
    }

    public SubscribeUserResponseDto createSubscribeUserByOrderConfirm(Long subscribeId, Long userId) {
        Subscribe subscribe = verifySubscribe(subscribeId);
        User findUser = userService.findUserEntity(userId);
        SubscribeUser newSubUser = SubscribeUser.create(subscribe, findUser, SubscribeStatus.ACTIVE);
        SubscribeUser saveSubUser = subscribeRepository.saveSubscribeUser(newSubUser);
        return SubscribeUserResponseDto.of(saveSubUser);
    }

    public SubscribeUserResponseDto updateSubscribeUser(Long newsubscribeId, Long subscribeUserId, SubscribeUserPatchDto dto, User user) {
        // 기존의 구독 User 확인
        SubscribeUser findSubUser = verifySubUser(subscribeUserId);
    
        // newsubscribeId가 null이 아니고 기존 subscribeId와 다를 경우 변경
        if (newsubscribeId != null && !newsubscribeId.equals(findSubUser.getSubscribeId())) {
            // 새로운 구독 ID로 업데이트
            findSubUser.setSubscribeId(newsubscribeId);
        }
        
        // 구독 정보를 업데이트
        SubscribeUser update = findSubUser.update(dto);
        
        // 변경된 구독 정보를 저장
        SubscribeUser saveSubUser = subscribeRepository.saveSubscribeUser(update);
        
        // 응답 DTO로 반환
        return SubscribeUserResponseDto.of(saveSubUser);
    }
    
    

    public Page<SubscribeUserResponseDto> findAllSubscribeUser(Long userId, int page, User user) {
        return subscribeRepository.findAllSubscribeByUserId(userId, PageRequest.of(page, 10, Sort.by("createAt").descending()))
                .map(SubscribeUserResponseDto::of);
    }


    public SubscribeResponseDto createSubscribe(SubscribePostDto dto, User user) {
        Subscribe newSub = Subscribe.create(dto);
        
        return SubscribeResponseDto.of(subscribeRepository.save(newSub));
    }

    public SubscribeResponseDto updateSubscribe(Long subscribeId, SubscribePostDto dto, User user) {
        Subscribe find = verifySubscribe(subscribeId);
        Subscribe updateSub = find.update(dto);
        return SubscribeResponseDto.of(subscribeRepository.save(updateSub));

    }

    public void deleteSubscribe(Long subscribeId) {
        subscribeRepository.deleteById(subscribeId);
    }

    private Subscribe verifySubscribe(Long subscribeId) {
        return subscribeRepository.findById(subscribeId)
                .orElseThrow(() -> new ServiceLogicException(ErrorCode.NOT_FOUND));
    }

    public SubscribeUserResponseDto verifyActiveSubUser(Long userId) {
        Optional<SubscribeUser> find = subscribeRepository.findSubscribeUserByUserIdAndStatus(userId, SubscribeStatus.ACTIVE);
        return find.map(SubscribeUserResponseDto::of).orElse(null);
    }

    public SubscribeUser getActiveSubscribeUser(Long userId) {
        return subscribeRepository.findSubscribeUserByUserIdAndStatus(userId, SubscribeStatus.ACTIVE)
                .orElseThrow(() -> new ServiceLogicException(ErrorCode.NOT_FOUND));
    }


    public void verifyActiveSubUserThrowError(Long userId) {
        Optional<SubscribeUser> find = subscribeRepository.findSubscribeUserByUserIdAndStatus(userId, SubscribeStatus.ACTIVE);
        if (find.isPresent()) {
            throw new ServiceLogicException(ErrorCode.ALREADY_ACTIVE_SUBSCRIBE);
        }
    }

    private SubscribeUser verifySubUser(Long subscribeUserId) {
        return subscribeRepository.findSubUser(subscribeUserId)
                .orElseThrow(() -> new ServiceLogicException(ErrorCode.NOT_FOUND));
    }


    @Scheduled(cron = "0 0 0 * * *")
    public void checkAndExpireSubscriptions() {
        LocalDate currentDate = LocalDate.now();
        List<SubscribeUser> expiredSubscriptions = subscribeRepository.findByExpirationDateBeforeAndSubscribeStatus(currentDate, SubscribeStatus.ACTIVE);

        for (SubscribeUser subscription : expiredSubscriptions) {
            subscription.setSubscribeStatus(SubscribeStatus.EXPIRATION);
            subscribeRepository.saveSubscribeUser(subscription);
        }
    }

}
